const dialog = document.getElementById("help-dialog");
const openButton = document.getElementById("open-modal");

if (dialog && openButton) {
  openButton.addEventListener("click", () => dialog.showModal());
}

# Semantic HTML5 & Accessible Component Architecture

An accessible multi-page enterprise dashboard foundation using semantic HTML5 and WCAG 2.1-oriented practices.

## Included
- Semantic `header`, `nav`, `main`, `section`, `article`, `aside`, and `footer`.
- Keyboard-friendly skip link and visible focus indicators.
- Accessible tables with captions and scoped headers.
- Forms with labels, fieldsets, legends, required fields, autocomplete, and validation attributes.
- Native accessible `<dialog>` modal.
- Three pages: Dashboard, Reports, and Settings.

## Validation
Validate `index.html`, `reports.html`, and `settings.html` with the W3C Nu HTML Checker:
https://validator.w3.org/nu/

The files are written to be valid HTML5 and should be checked after any future changes.

## Run
Open `index.html` in a browser or serve the folder with a local static server.
